"""crabcraft.py

Usage:
  crabcraft.py ping
  crabcraft.py players
  crabcraft.py query <user>
  crabcraft.py stats <user> <category> <stat> 
  crabcraft.py (-h | --help)
  crabcraft.py --version

Options:
  -h --help  Show this help mesage and exit
  --version  Show version

"""

__version__ = '1.0'
__author__ = 'lxviolet'

# Standard library imports
import argparse
import sys

# Third-party imports
from docopt import docopt

# Local module imports
import api


def ping():
    print('ping!')
def players():
    print('players!')
def query():
    print('query!')
def stats():
    print('stats!')


args = docopt(__doc__, version=__version__)
print(args)

# FIXME: this is ugly! really ugly! i hate this! fix this! this sucks!
match args:
    case {'ping': True, 'players': False, 'query': False, 'stats': False}:
        ping()
    case {'ping': False, 'players': True, 'query': False, 'stats': False}:
        players()
    case {'ping': False, 'players': False, 'query': True, 'stats': False}:
        query()
    case {'ping': False, 'players': False, 'query': False, 'stats': True}:
        stats()
    case _:
        print('If you\'re seeing this, the code is in what I thought'
              'was an unreachable state state.\n\nI could give you '
              'advice for what to do, but honestly, why should you '
              'trust me? I clearly screwed this up. I\'m writing an '
              'error message that should never appear, yet I know it '
              'probably will someday.\n\nOn a deeper level, I know '
              'I\'m not up to this task. I\'m truly sorry.')
