"""Handles requests to the CrabCraft API

"""

import http.client

